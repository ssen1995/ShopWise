# ShopWise — backend MVP

## What this does
- FastAPI backend + SQLite database
- Product catalog and retailer offers
- First-party price snapshot storage
- Price history endpoint
- AI-agent endpoint for product/deal/buy-wait queries
- Server-side image proxy to avoid many hotlink/CORS failures
- Seed data so the site works immediately
- Credential-ready retailer connectors

## Run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open http://127.0.0.1:8000

## Live retailer data
Add credentials to `.env` and implement/enable the retailer adapters. Amazon currently uses Creators API; PA-API 5 is deprecated. Flipkart provides affiliate product/search APIs.

Never put retailer API secrets in the browser/frontend.

## Database
`shopwise.db` is created automatically. `price_history` is append-only in the MVP so each scheduled sync can become a new observation.
